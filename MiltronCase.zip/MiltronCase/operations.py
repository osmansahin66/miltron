import requests
import socket
from typing import List

from _types import Rocket, Telemetry, Payload, Timestamps
from multiprocessing import Process


def get_rockets_and_initialize_tcp_connections():
    rockets = get_rockets()
    if len(rockets) > 0:
        _initialize_tcp_connections(rockets)


def get_rockets() -> List[Rocket]:
    rockets_url = "http://localhost:5000/rockets"

    while True:
        try:
            response = requests.get(rockets_url, headers={"x-api-key": "API_KEY_1"})
            if response.status_code == 200:
                rockets: List[Rocket] = []
                response_json = response.json()
                for rocket_json in response_json:
                    rockets.append(Rocket(
                        id=rocket_json["id"],
                        model=rocket_json["model"],
                        mass=rocket_json["mass"],
                        payload=Payload(
                            description=rocket_json["payload"]["description"],
                            weight=rocket_json["payload"]["weight"],
                        ),
                        telemetry=Telemetry(
                            host=rocket_json["telemetry"]["host"],
                            port=rocket_json["telemetry"]["port"],
                        ),
                        status=rocket_json["status"],
                        timestamps=Timestamps(
                            launched=rocket_json["timestamps"]["launched"],
                            deployed=rocket_json["timestamps"]["deployed"],
                            failed=rocket_json["timestamps"]["failed"],
                            cancelled=rocket_json["timestamps"]["cancelled"],
                        ),
                        altitude=rocket_json["altitude"],
                        speed=rocket_json["speed"],
                        acceleration=rocket_json["acceleration"],
                        thrust=rocket_json["thrust"],
                        temperature=rocket_json["temperature"],
                    ))

                return rockets
        except BaseException:
            return []


def _initialize_tcp_connections(rockets: List[Rocket]):
    for rocket in rockets:
        p = Process(target=_run_tcp_client, args=(rocket["telemetry"]["host"], rocket["telemetry"]["port"]))
        p.start()


def _run_tcp_client(host: str, port: int):
    client_socket = socket.socket()
    try:
        client_socket.connect((host, port))
        # udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # i = 10
        # while i > 0:
        while True:
            data = client_socket.recv(1024)
            # start_byte = data[0:1]
            rocket_id = data[1:11]
            packet_number = data[11:12]
            print(rocket_id)
            # packet_size = data[12:13]
            # altitude = data[13:17]
            # speed = data[17:21]
            # acceleration = data[17:21]
            # thrust_as_newton = data[21:25]
            # temperature = data[25:29]
            # crc_16_buypass = data[29:31]

            # print("rocket id = " + rocket_id.decode('utf-8'))
            # print("packet number = ", int.from_bytes(packet_number, "big"))
            # print("packet size = ", int.from_bytes(packet_size, "big"))
            # print("altitude = ", struct.unpack('f', altitude), "mt")
            # print("speed = ", struct.unpack('f', speed), "m/s")
            # print("acceleration = ", struct.unpack('f', acceleration), "m/s2")
            # print("thrust as newton = ", struct.unpack('f', thrust_as_newton), "N")
            # print("temperature = ", struct.unpack('f', temperature), "C")
            # print("temperature = ", struct.unpack('H', crc_16_buypass), "CRC16/BUYPASS")
    except BaseException:
        client_socket.close()
