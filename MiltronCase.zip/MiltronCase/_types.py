from typing import Optional
from datetime import datetime
from typing_extensions import TypedDict


class Payload(TypedDict):
    description: str
    weight: int


class Telemetry(TypedDict):
    host: str
    port: int


class Timestamps(TypedDict):
    launched: Optional[datetime]
    deployed: Optional[datetime]
    failed: Optional[datetime]
    cancelled: Optional[datetime]


class Rocket(TypedDict):
    id: str
    model: str
    mass: int
    payload: Payload
    telemetry: Telemetry
    status: str
    timestamps: Timestamps
    altitude: float
    speed: float
    acceleration: float
    thrust: int
    temperature: float
