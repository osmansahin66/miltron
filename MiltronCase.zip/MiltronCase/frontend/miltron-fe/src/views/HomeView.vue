<template>
  <div class="main">
    <div class="rockets">
      <div v-for="rocket in rockets" class="rocket">
        <div>
          <button @click=setSelectedRocket(rocket) class="rocket-button"> {{ rocket["id"] }} - {{ rocket["model"]
          }}</button>
        </div>
        <hr />
      </div>
    </div>
    <div class="content">
      <div class="title-and-value">
        <span class="title">ID</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["id"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Model</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["model"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Acceleration</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["acceleration"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Mass</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["mass"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Speed</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["speed"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Acceleration</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["acceleration"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Status</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["status"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Temperature</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["temperature"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Payload</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["payload"]["description"] }}</span>
      </div>
      <div class="title-and-value">
        <span class="title">Payload Weight</span>
        <span class="value">: {{ selectedRocket !== null && selectedRocket["payload"]["weight"] }}</span>
      </div>
    </div>
  </div>
</template>


<script setup>
import axios from 'axios';
import { onMounted, ref } from 'vue';

const rockets = ref([]);
const selectedRocket = ref(null)


onMounted(() => {
  axios.get('http://127.0.0.1:8000/')
    .then(function (response) {
      rockets.value = response.data;
      selectedRocket.value = rockets.value[0];

      // initializeWebSocket()
    })
    .catch(function (error) {
      console.error(error);
    })
});

function initializeWebSocket() {
  var ws = new WebSocket(`ws://localhost:8000/rocket/${selectedRocket['id']}/ws`);
  ws.onmessage = function (event) {
    console.log(event.data)
  };
}

function setSelectedRocket(rocket) {
  selectedRocket.value = rocket
}

</script>

<style>
.main {
  display: flex;
  min-width: 80rem;

  .rockets {
    width: 40%;
  }

  .rocket {
    background-color: #fff;
    color: black;
    padding: 8px;

    .rocket-button {
      background-color: #fff;
      border: none;
      cursor: pointer;
    }
  }

  .rocket:hover {
    background-color: beige;

    .rocket-button {
      background-color: beige;
    }
  }

  .content {
    background-color: #fff;
    color: black;
    width: 90%;
    margin-left: 10px;

    .title-and-value {
      display: flex;

      .title {
        width: 10rem;
        font-weight: bold;
      }
    }
  }
}
</style>
