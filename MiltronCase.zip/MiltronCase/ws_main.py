from operations import get_rockets_and_initialize_tcp_connections


def main():
    get_rockets_and_initialize_tcp_connections()


if __name__ == "__main__":
    main()
